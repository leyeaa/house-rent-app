<?php include('db_connect.php');?>

<div class="container-fluid">
	
	<div class="col-lg-12">
		<div class="row mb-4 mt-4">
			<div class="col-md-12">
				
			</div>
		</div>
		<div class="row">
			<!-- FORM Panel -->

			<!-- Table Panel -->
			<div class="col-md-12">
				<div class="card">
					<div class="card-header">
						<b>List of Landlord</b>
						<span class="float:right"><a class="btn btn-primary btn-block btn-sm col-sm-2 float-right" href="javascript:void(0)" id="new_landlord">
					<i class="fa fa-plus"></i> New Landlord
				</a></span>
					</div>
					<div class="card-body">
						<table class="table table-condensed table-bordered table-hover">
							<thead>
								<tr>
									<th class="text-center">#</th>
									<th class="">Name</th>
									<th class="">No of Houses</th>
									<th class="">Total Payments</th>
									<th class="">Outstanding Balance</th>
									<th class="text-center">Actions</th>
								</tr>
							</thead>
							<tbody>
								<?php 
								$i = 1;
								$tenant = $conn->query("SELECT * FROM landlord WHERE status=1");
								while($row=$tenant->fetch_assoc()):
									$total=0;
									$payment = $conn->query("SELECT t.house_id, t.date_in, h.price FROM tenants t LEFT JOIN houses h ON t.house_id=h.id WHERE h.landlord=".$row['id']." AND t.status=1");
									if($payment->num_rows > 0):
										while($rec=$payment->fetch_assoc()):
											$months = abs(strtotime(date('Y-m-d')." 23:59:59") - strtotime($rec['date_in']." 23:59:59"));
											$months = floor(($months) / (30*60*60*24));
											$payable = $rec['price'] * $months;
											$total+=$payable;
										endwhile;
									endif;
								
									$paid = $conn->query("SELECT SUM(amount) as paid FROM payments where tenant_id IN (SELECT id FROM tenants WHERE status=1 AND house_id IN (SELECT id FROM houses WHERE landlord=".$row['id'].") )");
									$paid = $paid->num_rows > 0 ? $paid->fetch_array()['paid'] : 0;
									$outstanding = $total-$paid;
									$no_houses = $conn->query("SELECT * FROM houses where landlord =".$row['id']);
								
								?>
								<tr>
									<td class="text-center"><?php echo $i++ ?></td>
									<td>
										<?php echo ucwords($row['firstname']).' '.ucwords($row['middlename']).' '.ucwords($row['lastname']) ?>
									</td>
									<td class="">
										 <p> <b><?php echo $no_houses->num_rows ?></b></p>
									</td>
									<td class="">
										 <p> <b><?php echo number_format($paid,2) ?></b></p>
									</td>
									<td class="text-right">
										 <p> <b><?php echo number_format($outstanding,2) ?></b></p>
									</td>
									<td class="text-center">
										<button class="btn btn-sm btn-outline-primary view_properties_landlord" type="button" data-id="<?php echo $row['id'] ?>" >View Properties</button>
										<button class="btn btn-sm btn-outline-primary view_payment_landlord" type="button" data-id="<?php echo $row['id'] ?>" >View Details</button>
										<button class="btn btn-sm btn-outline-primary edit_landlord" type="button" data-id="<?php echo $row['id'] ?>" >Edit Details</button>
										<button class="btn btn-sm btn-outline-danger delete_landlord" type="button" data-id="<?php echo $row['id'] ?>">Delete</button>
									</td>
								</tr>
								<?php endwhile; ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
			<!-- Table Panel -->
		</div>
	</div>	

</div>
<style>
	
	td{
		vertical-align: middle !important;
	}
	td p{
		margin: unset
	}
	img{
		max-width:100px;
		max-height: :150px;
	}
</style>
<script>
	$(document).ready(function(){
		$('table').dataTable()
	})
	
	$('#new_landlord').click(function(){
		uni_modal("New Landlord","manage_landlord.php","mid-large")
		
	})

	$('.view_payment_landlord').click(function(){
		uni_modal("Landlord Payments","view_payment_landlord.php?id="+$(this).attr('data-id'),"large")
		
	})
	$('.view_properties_landlord').click(function(){
		uni_modal("Landlord Properties","view_properties_landlord.php?id="+$(this).attr('data-id'),"large")
		
	})
	$('.edit_landlord').click(function(){
		uni_modal("Manage Landlord Details","manage_landlord.php?id="+$(this).attr('data-id'),"mid-large")
		
	})
	$('.delete_landlord').click(function(){
		_conf("Are you sure to delete this Landlord?","delete_landlord",[$(this).attr('data-id')])
	})
	
	function delete_tenant($id){
		start_load()
		$.ajax({
			url:'ajax.php?action=delete_landlord',
			method:'POST',
			data:{id:$id},
			success:function(resp){
				if(resp==1){
					alert_toast("Data successfully deleted",'success')
					setTimeout(function(){
						location.reload()
					},1500)

				}
			}
		})
	}
</script>