<?php 

$conn= new mysqli('localhost','reedscar_oyepo','Realestate@1','reedscar_oyepo')or die("Could not connect to mysql".mysqli_error($con));
