<?php include 'db_connect.php' ?>

<?php 
$landlord=$conn->query("SELECT * FROM landlord WHERE id = {$_GET['id']} ");
$landlord = $landlord->fetch_array()
?>
<div class="container-fluid">
	<div class="col-lg-12">
		<div class="row">
			<div class="col-md-4">
				<div id="details">
					<large><b>Details</b></large>
					<hr>
					<p>Landlord: <b><?php echo ucwords($landlord['firstname']).' '.ucwords($landlord['middlename']).' '.ucwords($landlord['lastname']) ?></b></p>
					<p>Contact: <b><?php echo $landlord['contact'] ?></b></p>
					<p>Email: <b><?php echo $landlord['email'] ?></b></p>
					<p>Registered Date: <b><?php echo $landlord['date_in'] ?></b></p>
				</div>
			</div>
			<div class="col-md-8">
				<large><b>House List</b></large>
					<hr>
				<table class="table table-condensed table-striped">
					<thead>
						<tr>
							<th>Category</th>
							<th>House No</th>
							<th>Description</th>
						</tr>
					</thead>
					<tbody>
						<?php 
						$houses = $conn->query("SELECT h.*, c.* FROM houses h, categories c WHERE h.category_id=c.id AND h.landlord={$_GET['id']}");
						
						if($houses->num_rows > 0):
						while($row=$houses->fetch_assoc()):
						?>
					<tr>
						<td><?php echo $row['name'] ?></td>
						<td><?php echo $row['house_no'] ?></td>
						<td><?php echo $row['description'] ?></td>
					</tr>
					<?php endwhile; ?>
					<?php else: ?>
					<?php endif; ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<style>
	#details p {
		margin: unset;
		padding: unset;
		line-height: 1.3em;
	}
	td, th{
		padding: 3px !important;
	}
</style>