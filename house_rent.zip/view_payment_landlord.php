<?php include 'db_connect.php' ?>

<?php 
$landlord=$conn->query("SELECT * FROM landlord WHERE id = {$_GET['id']} ");
$landlord = $landlord->fetch_array()
?>
<div class="container-fluid">
	<div class="col-lg-12">
		<div class="row">
			<div class="col-md-4">
				<div id="details">
					<large><b>Details</b></large>
					<hr>
					<p>Landlord: <b><?php echo ucwords($landlord['firstname']).' '.ucwords($landlord['middlename']).' '.ucwords($landlord['lastname']) ?></b></p>
					<p>Contact: <b><?php echo $landlord['contact'] ?></b></p>
					<p>Email: <b><?php echo $landlord['email'] ?></b></p>
					<p>Registered Date: <b><?php echo $landlord['date_in'] ?></b></p>
				</div>
			</div>
			<div class="col-md-8">
				<large><b>Payment List</b></large>
					<hr>
				<table class="table table-condensed table-striped">
					<thead>
						<tr>
							<th>Date</th>
							<th>House No</th>
							<th>Amount</th>
						</tr>
					</thead>
					<tbody>
						<?php 
						$payments = $conn->query("SELECT * FROM payments where tenant_id IN (SELECT id FROM tenants WHERE status=1 AND house_id IN (SELECT id FROM houses WHERE landlord={$_GET['id']}) )");
						
						if($payments->num_rows > 0):
						while($row=$payments->fetch_assoc()):
							$house = $conn->query("SELECT * FROM houses WHERE id=(SELECT house_id FROM tenants WHERE id=(SELECT tenant_id FROM payments WHERE id=".$row['id']."))");
							$house = $house->fetch_array()
						?>
					<tr>
						<td><?php echo date("M d, Y",strtotime($row['date_created'])) ?></td>
						<td><?php echo $house['house_no'] ?></td>
						<td class='text-right'><?php echo number_format($row['amount'],2) ?></td>
					</tr>
					<?php endwhile; ?>
					<?php else: ?>
					<?php endif; ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<style>
	#details p {
		margin: unset;
		padding: unset;
		line-height: 1.3em;
	}
	td, th{
		padding: 3px !important;
	}
</style>